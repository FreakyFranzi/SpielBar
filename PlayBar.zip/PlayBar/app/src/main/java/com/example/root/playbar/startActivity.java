package com.example.root.playbar;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class startActivity extends Activity implements View.OnClickListener{

    Button btnYes;
    Button btnNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        btnYes = (Button) findViewById(R.id.bt_yes);
        btnYes.setOnClickListener(this);
        btnNo = (Button) findViewById(R.id.bt_no);
        btnNo.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent name = new Intent(this, GiveNameActivity.class
        );

        switch (view.getId()){
            case R.id.bt_yes:
                startActivity(name);
                this.finish();
                break;
            case R.id.bt_no:
                this.finish();
                break;
        }

    }
}
