package com.example.root.playbar;

/**
 * Created by root on 19.11.17.
 */

public class globalVariables {

    String playersname;

    public void setPlayersname(String i_playersname){
        playersname = i_playersname;
    }

    public String getPlayersname(){
        return playersname;
    }

}


