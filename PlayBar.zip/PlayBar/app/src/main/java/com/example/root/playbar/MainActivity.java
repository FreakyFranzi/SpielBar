package com.example.root.playbar;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener{
    Button btnevent;
    Button btngroup;
    Button btnsingle;
    Button btnhighscore;
    String s_playersname;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btngroup = (Button) findViewById(R.id.bt_group);
        btngroup.setOnClickListener(this);
        btnsingle = (Button) findViewById(R.id.bt_single);
        btnsingle.setOnClickListener(this);
        btnhighscore = (Button) findViewById(R.id.bt_highscore);
        btnhighscore.setOnClickListener(this);
        btnevent = (Button) findViewById(R.id.bt_events);
        btnevent.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent group = new Intent(this, GroupActivitz.class);

        switch (view.getId()){
            case R.id.bt_group:
                startActivity(group);
                this.finish();
                break;
            case R.id.bt_single:

                break;
            case R.id.bt_highscore:

                break;
            case R.id.bt_events:

                break;
        }

    }
}
